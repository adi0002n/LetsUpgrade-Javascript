//Program to search for a element in an array of strings.

//Let the give array of string be:
let arr = ["html", "css", "javascript", "bootstrap", "php", "sql", "c", "c++"];

//Let the elements be searched is:
let search = "javascript";

//for-loop to select elements of given array consecutively.
for(let i=0; i<arr.length; i++) {

    //if condition to check weather the selected element of array element is similar to the searced element.
    if(search == arr[i]){
        console.log(`"${search}" exists in [${arr}].`);
    }
}
