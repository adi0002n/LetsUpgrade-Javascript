//Print an array in reverse order.

//Let the give array be:
let ordered_arr = ["html", "css", "javascript", "bootstrap", "php", "sql", "c", "java"];

//Let the give array be:
let reversed_arr=[];

//loop to copy the ordered_arr element in reversed_arr in reversed order.
for(let i=ordered_arr.length-1; i>=0; i--) {

    let j = (ordered_arr.length-1)-i;
    reversed_arr[j] = ordered_arr[i];
}

console.log(`[${ordered_arr}] when rversed results to: [${reversed_arr}]`);