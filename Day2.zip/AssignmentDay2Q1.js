//Program to search or a particular character in a string.

//Let the give string be:
let str = "javascript";

//Let the elements be searched is:
let search = "a";

//for-loop to select character of given string consecutively.
for(let i=0; i<str.length; i++) {

    //if condition to check weather the character of string is similar to the searced character.
    if(search == str[i]){
        console.log(`${search} exists in ${str}.`);
        break;
    }
}