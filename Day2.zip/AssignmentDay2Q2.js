//Program to convert minutes into seconds.

//Let given time in minutes:
let t_min = 2704; 

//Time in seconds = (time in minute X 60)
let t_sec = t_min*60 ;
console.log(`${t_min} min equals ${t_sec} sec.`);