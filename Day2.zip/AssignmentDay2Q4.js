//Program to display only elements containing 'a' in them from an array.

//Let the give array be:
let arr = ["html", "css", "javascript", "bootstrap", "php", "sql", "c", "java"];

//Let the elements be searched is:
let search = "a";

//for-loop to check whether array elements contains 'a'.

//for-loop to select elements of given array consecutively
for(let i=0; i<arr.length; i++) {

    //for-loop to select the characters of elements of given array.
    for(let j=0; j<arr[i].length; j++){
        
        //if condition to check weather the selected character of array element is 'a' or not.
        if(search == arr[i][j]){
            console.log( `${arr[i]} contains "${search}".`);
            break;
        }


    }
}
