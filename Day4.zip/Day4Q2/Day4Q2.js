// ADITYA NARAYAN CHARASIA
// Question 2
// Create a webpage containing two input fields and a button.
// A. Write something in the first input
// B. On click of the button, the content of input one should be copied in the second input


function copy(){
    const txt1= document.getElementById("text1");
    const value1=txt1.value;
	const txt2= document.getElementById("text2");
    const value2=txt2.value;
    // console.log(txt1.value)
    const final=value1+value2;
    alert(final);
    
}