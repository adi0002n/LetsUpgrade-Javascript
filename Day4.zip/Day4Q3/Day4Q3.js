//ADITYA NARAYAN CHARASIA
//  Question 3
// Create an array of objects with objects having the following properties
// A. {name (string), age (number), country (string), hobbies array (string [ ] ) }
// B. Write a function to display all the objects on the console


// An array of objects with objects
let SuperHeros=[

    {
       name : "Iron Man",
       age : 48,
       country : "America",
       hobby : ["building a suit of armor"]
    },
    {
        name: "Captain American" ,
        age : 100 ,
        country : "America",
        hobby : ["Skilled military leader" , "strategist"]
    },
    {
       name : "Thor" ,
       age : 1500,
       country : "Asgard" ,
       hobby : ["Superhuman strength", "speed", "endurance" , "resistance to injury"]
    },
    {
        name : "Shakti",
        age : 34,
        country : "India",
        hobby : ["She can generate fire from her bare hands", "ability to convert any metal into a weapon"]
     },
    {
        name : "Ra-One" ,
        age : 49 ,
        country : "India",
        hobby : ["shoot blasts of energy from his hands", "can shoot special bullets"]
    },
    {
        name : "Krrish",
        age : 42 ,
        country : "India",
        hobby : ["jumping to and from great heights", "super human strength", "super fast reflex actions"]
    },
    {
        name : "Devi" ,
        age : 42 ,
        country : "India",
        hobby : ["human warriors of light"]
    },
    {
        name : "Inspector Steel",
        age : 101 ,
        country : "India",
        hobby : ["x-ray vision", "lie detector", "scanners", "a Mega gun"]
    },
    {
        name : "Nagraj" ,
        age : 47 ,
        country : "India",
        hobby : ["shape shifting", "releasing various types of snakes"]
    },
    {
        name : "Doga",
        age : 40 ,
        country : "India",
        hobby : [" muscle development", "hand to hand combat", "martial arts", "marksmanship"]
    },
    {
        name : "Shaktimaan",
        age : 50 ,
        country :"India" ,
        hobby : ["activating certain chakras which gave him powers"]
    }
]
    
// function to display all the objects on the console in TABULAR FORM

console.table(SuperHeros)

// for (let i = 0; i < SuperHeros.length; i++) {
//     console.log(SuperHeros[i]);
    
// }