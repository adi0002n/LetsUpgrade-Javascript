//ADITYA NARAYAN CHARASIA
//  Question 1
// Create a webpage containing an image and three buttons
// A. On click of the second button a change the existing image to a new image
// B. On click of the third button change it once again
// C. On click of first, the first image should come back -->


//Button 1 for Image 1
function img1(){
	const  ele = document.getElementById("img");
	const newurl="1.jpg";
	ele.src=newurl;
}

//Button 1 for Image 1
function img2(){
	const  ele = document.getElementById("img");
	const newurl="2.jpg";
	ele.src=newurl;
}

//Button 1 for Image 1
function img3(){
	const  ele = document.getElementById("img");
	const newurl="3.jpg";
	ele.src=newurl;
}