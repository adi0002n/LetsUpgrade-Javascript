// ADITYA NARAYAN CHARASIA
//Question 4
// Following the 3rd question
// A. Write a function to display all the objects having age less than 30
// B. Write a function to display all the objects having country India

// An array of objects with objects
let SuperHeros=[

    {
       name : "Iron Man",
       age : 27,
       country : "America",
       hobby : ["building a suit of armor"]
    },
    {
        name: "Captain American" ,
        age : 100 ,
        country : "America",
        hobby : ["Skilled military leader" , "strategist"]
    },
    {
       name : "Thor" ,
       age : 1500,
       country : "Asgard" ,
       hobby : ["Superhuman strength", "speed", "endurance" , "resistance to injury"]
    },
    {
        name : "Shakti",
        age : 24,
        country : "India",
        hobby : ["She can generate fire from her bare hands", "ability to convert any metal into a weapon"]
     },
    {
        name : "Ra-One" ,
        age : 49 ,
        country : "India",
        hobby : ["shoot blasts of energy from his hands", "can shoot special bullets"]
    },
    {
        name : "Krrish",
        age : 42 ,
        country : "India",
        hobby : ["jumping to and from great heights", "super human strength", "super fast reflex actions"]
    },
    {
        name : "Devi" ,
        age : 29 ,
        country : "India",
        hobby : ["human warriors of light"]
    },
    {
        name : "Inspector Steel",
        age : 101 ,
        country : "India",
        hobby : ["x-ray vision", "lie detector", "scanners", "a Mega gun"]
    },
    {
        name : "Nagraj" ,
        age : 47 ,
        country : "India",
        hobby : ["shape shifting", "releasing various types of snakes"]
    },
    {
        name : "Doga",
        age : 38 ,
        country : "India",
        hobby : [" muscle development", "hand to hand combat", "martial arts", "marksmanship"]
    },
    {
        name : "Shaktimaan",
        age : 50 ,
        country :"India" ,
        hobby : ["activating certain chakras which gave him powers"]
    }
]
  
// function to display all the objects having age less than 30 in TABULAR FORM

let j=0;
let unedr30=[];
for (let i = 0; i < SuperHeros.length; i++) {
    if (SuperHeros[i].age < 30) {
        // console.log(SuperHeros[i]);
        unedr30[j]=SuperHeros[i];
        j++;
    }    
}
console.log("\n\n\n\nThe objects having age less than 30");
console.table(unedr30);

// function to display all the objects having country India in TABULAR FORM

let k=0;
let indian=[];
for (let i = 0; i < SuperHeros.length; i++) {
    if (SuperHeros[i].country == "India") {
        // console.log(SuperHeros[i]);
        indian[k]=SuperHeros[i];
        k++;
    }    
}
console.log("\n\n\n\nThe objects having country as India are:");
console.table(indian);